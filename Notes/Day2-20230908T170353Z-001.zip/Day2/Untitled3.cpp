#include<iostream>

using namespace std;

enum mobileNos{Ajay, Riya=9876548978, Rahul};

int main(){

	cout<<Ajay;
	return 0;
}
