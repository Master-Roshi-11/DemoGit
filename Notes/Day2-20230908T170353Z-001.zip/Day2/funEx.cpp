#include<iostream>

using namespace std;

void show();

int main(){

	show();
}
void show(){
	cout<<"Hello";
}
