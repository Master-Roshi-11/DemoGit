#include<iostream>

using namespace std;

int main(){
	
	int x,y;
	std::cout<<"Enter 2 number";
	std::cin>>x>>y;
	
	std::cout<<"x="<<x<<std::endl;
	std::cout<<"y="<<y;
	return 0;
}
